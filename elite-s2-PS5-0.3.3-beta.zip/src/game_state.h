#ifndef PADBRIDGE_GAME_STATE_H
#define PADBRIDGE_GAME_STATE_H

#include <stdint.h>

#define PB_GAME_STATE_PORT 9877
#define PB_GAME_STATE_MAGIC 0x46534731u
#define PB_GAME_STATE_VERSION 1u

enum {
    PB_GAME_UNKNOWN = 0,
    PB_GAME_NOT_LOADED = 1,
    PB_GAME_LOADED_UNKNOWN = 2,
    PB_GAME_ACTIVE_RUNNING = 3,
    PB_GAME_SUSPENDED_OR_HOME = 4
};

typedef struct {
    uint32_t version;
    uint32_t classification;
    uint32_t confidence;
    uint32_t pid;
    int32_t proc_state;
    uint64_t runtime_us;
    uint32_t pctcpu;
    uint32_t slptime;
    uint32_t game_appid;
    uint32_t controller_focus;
    int32_t msgbuf_rc;
    uint32_t msgbuf_size;
    uint32_t msgbuf_scanned;
    uint32_t fw_version;
    char titleid[16];
    char contentid[64];
    char comm[32];
    char focus_to[96];
    char lifecycle[32];
    char reason[160];
    char last_line[256];
} pb_game_state;

/* Query the local PS Game State Lib daemon. Returns 1 on a valid response,
 * 0 when the service is unavailable or its response is invalid. */
int pb_game_state_query(pb_game_state *out);
const char *pb_game_state_name(uint32_t classification);

#endif

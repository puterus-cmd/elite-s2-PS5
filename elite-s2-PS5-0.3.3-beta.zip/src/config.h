/* /data/padbridge/config.ini: the few things worth changing.
 *
 *   menu_combo   = options+l2+r2      buttons held to open the menu on the console
 *   menu_hold_ms = 1500                how long they are held (500..5000)
 *
 * Button names: l1 r1 l2 r2 l3 r3 cross circle square triangle up down left
 * right options create touchpad. At least two. The PS button cannot be read.
 * Lines starting with # are comments. A line that is not understood is
 * reported and skipped; the defaults stand for anything missing or wrong. */
#ifndef PADBRIDGE_CONFIG_H
#define PADBRIDGE_CONFIG_H

#include "pad.h"

#include <stddef.h>

#define CONFIG_MAX_GAME_PROFILES 8
#define CONFIG_PROFILE_NAME_MAX 24

typedef struct {
    char name[CONFIG_PROFILE_NAME_MAX];
    uint32_t paddle_map[4];
} padbridge_game_profile;

typedef struct {
    uint32_t menu_combo;
    int menu_hold_ms;
    /* Elite Series 2 paddles in HID bit order: UR, LR, UL, LL.
     * Each value is one ScePadData button bit, or zero for disabled. */
    uint32_t paddle_map[4];
    padbridge_game_profile profiles[CONFIG_MAX_GAME_PROFILES];
    unsigned profile_count;
    unsigned active_profile;
} padbridge_config;

void config_defaults(padbridge_config *c);

/* Reads `path`. Returns the number of lines not understood; a missing file
 * is not an error (returns 0, defaults kept). */
int config_load(padbridge_config *c, const char *path);

/* "options+l2+r2" -> mask. Returns 0 if a name is unknown or fewer than two
 * buttons are named. */
int config_parse_combo(const char *text, uint32_t *mask);

/* Mask -> words for a person: "L2 + R2 + OPTIONS". */
void config_combo_text(uint32_t mask, char *out, size_t max);

/* One PS5 button name (or "none") to/from its ScePadData bit. */
int config_parse_button(const char *text, uint32_t *button);
const char *config_button_name(uint32_t button);
int config_save(const padbridge_config *c, const char *path);
int config_profile_name_valid(const char *name);
int config_profile_create(padbridge_config *c, const char *name);
int config_profile_save_current(padbridge_config *c, unsigned slot);
int config_profile_activate(padbridge_config *c, unsigned slot);
int config_profile_rename(padbridge_config *c, unsigned slot, const char *name);
int config_profile_delete(padbridge_config *c, unsigned slot);
int config_profile_cycle(padbridge_config *c, int direction);

#endif

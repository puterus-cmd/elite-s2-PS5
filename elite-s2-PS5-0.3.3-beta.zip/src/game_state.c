#include "game_state.h"

#include <arpa/inet.h>
#include <errno.h>
#include <stddef.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

#define GS_TIMEOUT_MS 300

#if defined(__GNUC__)
#define PB_PACKED __attribute__((packed))
#else
#define PB_PACKED
#endif

typedef struct PB_PACKED {
    uint32_t magic, cmd, datalen;
} pb_gs_request;

typedef struct PB_PACKED {
    uint32_t version, classification, confidence, pid;
    int32_t proc_state;
    uint64_t runtime_us;
    uint32_t pctcpu, slptime, game_appid, controller_focus;
    int32_t msgbuf_rc;
    uint32_t msgbuf_size, msgbuf_scanned, fw_version;
    char titleid[16], contentid[64], comm[32], focus_to[96];
    char lifecycle[32], reason[160], last_line[256];
} pb_gs_wire_response;

_Static_assert(sizeof(pb_gs_wire_response) == 716, "PS Game State Lib v1 response layout changed");

static uint32_t le32(uint32_t v)
{
#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
    return __builtin_bswap32(v);
#else
    return v;
#endif
}

static int send_all(int fd, const void *data, size_t len)
{
    const unsigned char *p = data;
    while (len) {
        ssize_t n = send(fd, p, len, 0);
        if (n < 1) return 0;
        p += (size_t)n;
        len -= (size_t)n;
    }
    return 1;
}

static int recv_all(int fd, void *data, size_t len)
{
    unsigned char *p = data;
    while (len) {
        ssize_t n = recv(fd, p, len, 0);
        if (n < 1) return 0;
        p += (size_t)n;
        len -= (size_t)n;
    }
    return 1;
}

int pb_game_state_query(pb_game_state *out)
{
    struct sockaddr_in addr;
    struct timeval timeout = { 0, GS_TIMEOUT_MS * 1000 };
    pb_gs_request req;
    pb_gs_wire_response wire;
    uint32_t status;
    int fd, ok = 0;

    if (!out) return 0;
    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return 0;
    (void)setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    (void)setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(PB_GAME_STATE_PORT);
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) != 0) goto done;

    req.magic = le32(PB_GAME_STATE_MAGIC);
    req.cmd = le32(1);
    req.datalen = 0;
    if (!send_all(fd, &req, sizeof(req)) || !recv_all(fd, &status, sizeof(status))) goto done;
    if (le32(status) != 0 || !recv_all(fd, &wire, sizeof(wire))) goto done;

    if (le32(wire.version) != PB_GAME_STATE_VERSION ||
        le32(wire.classification) > PB_GAME_SUSPENDED_OR_HOME) goto done;
    memset(out, 0, sizeof(*out));
    out->version = le32(wire.version);
    out->classification = le32(wire.classification);
    out->confidence = le32(wire.confidence);
    out->pid = le32(wire.pid);
    out->proc_state = (int32_t)le32((uint32_t)wire.proc_state);
#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
    out->runtime_us = __builtin_bswap64(wire.runtime_us);
#else
    out->runtime_us = wire.runtime_us;
#endif
    out->pctcpu = le32(wire.pctcpu);
    out->slptime = le32(wire.slptime);
    out->game_appid = le32(wire.game_appid);
    out->controller_focus = le32(wire.controller_focus);
    out->msgbuf_rc = (int32_t)le32((uint32_t)wire.msgbuf_rc);
    out->msgbuf_size = le32(wire.msgbuf_size);
    out->msgbuf_scanned = le32(wire.msgbuf_scanned);
    out->fw_version = le32(wire.fw_version);
    memcpy(out->titleid, wire.titleid, sizeof(out->titleid));
    memcpy(out->contentid, wire.contentid, sizeof(out->contentid));
    memcpy(out->comm, wire.comm, sizeof(out->comm));
    memcpy(out->focus_to, wire.focus_to, sizeof(out->focus_to));
    memcpy(out->lifecycle, wire.lifecycle, sizeof(out->lifecycle));
    memcpy(out->reason, wire.reason, sizeof(out->reason));
    memcpy(out->last_line, wire.last_line, sizeof(out->last_line));
    out->titleid[sizeof(out->titleid)-1] = '\0';
    out->contentid[sizeof(out->contentid)-1] = '\0';
    out->comm[sizeof(out->comm)-1] = '\0';
    out->focus_to[sizeof(out->focus_to)-1] = '\0';
    out->lifecycle[sizeof(out->lifecycle)-1] = '\0';
    out->reason[sizeof(out->reason)-1] = '\0';
    out->last_line[sizeof(out->last_line)-1] = '\0';
    ok = 1;
done:
    close(fd);
    return ok;
}

const char *pb_game_state_name(uint32_t c)
{
    switch (c) {
    case PB_GAME_NOT_LOADED: return "not loaded";
    case PB_GAME_LOADED_UNKNOWN: return "loaded, state unknown";
    case PB_GAME_ACTIVE_RUNNING: return "active";
    case PB_GAME_SUSPENDED_OR_HOME: return "suspended or Home";
    default: return "unknown";
    }
}

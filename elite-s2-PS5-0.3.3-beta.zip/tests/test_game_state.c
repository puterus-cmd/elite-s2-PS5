#include "../src/game_state.h"

#include <arpa/inet.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#if defined(__GNUC__)
#define TEST_PACKED __attribute__((packed))
#else
#define TEST_PACKED
#endif

typedef struct TEST_PACKED {
    uint32_t version, classification, confidence, pid;
    int32_t proc_state;
    uint64_t runtime_us;
    uint32_t pctcpu, slptime, game_appid, controller_focus;
    int32_t msgbuf_rc;
    uint32_t msgbuf_size, msgbuf_scanned, fw_version;
    char titleid[16], contentid[64], comm[32], focus_to[96];
    char lifecycle[32], reason[160], last_line[256];
} test_wire_response;

_Static_assert(sizeof(test_wire_response) == 716, "test fixture must match v1 wire size");

typedef struct {
    int fd;
    uint32_t status;
    test_wire_response response;
    int request_ok;
} server_fixture;

static int recv_all(int fd, void *buf, size_t len)
{
    unsigned char *p = buf;
    while (len) {
        ssize_t n = recv(fd, p, len, 0);
        if (n <= 0) return 0;
        p += (size_t)n;
        len -= (size_t)n;
    }
    return 1;
}

static int send_all(int fd, const void *buf, size_t len)
{
    const unsigned char *p = buf;
    while (len) {
        ssize_t n = send(fd, p, len, 0);
        if (n <= 0) return 0;
        p += (size_t)n;
        len -= (size_t)n;
    }
    return 1;
}

static void *serve_one(void *arg)
{
    server_fixture *f = arg;
    struct { uint32_t magic, cmd, datalen; } req;
    int client = accept(f->fd, NULL, NULL);
    if (client >= 0) {
        if (recv_all(client, &req, sizeof req)) {
            f->request_ok = req.magic == 0x46534731u && req.cmd == 1 && req.datalen == 0;
            (void)send_all(client, &f->status, sizeof f->status);
            if (f->status == 0) (void)send_all(client, &f->response, sizeof f->response);
        }
        close(client);
    }
    close(f->fd);
    return NULL;
}

static int start_server(server_fixture *f, pthread_t *thread)
{
    struct sockaddr_in addr;
    int one = 1;
    memset(&addr, 0, sizeof addr);
    f->fd = -1;
    f->fd = socket(AF_INET, SOCK_STREAM, 0);
    if (f->fd < 0) return 0;
    setsockopt(f->fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
    addr.sin_family = AF_INET;
    addr.sin_port = htons(PB_GAME_STATE_PORT);
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (bind(f->fd, (struct sockaddr *)&addr, sizeof addr) != 0 || listen(f->fd, 1) != 0) {
        close(f->fd);
        f->fd = -1;
        return 0;
    }
    if (pthread_create(thread, NULL, serve_one, f) != 0) {
        close(f->fd);
        f->fd = -1;
        return 0;
    }
    return 1;
}

int main(void)
{
    int fail = 0;
#define CHECK(x) do { if (!(x)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #x); fail++; } } while (0)
    printf("game-state client: classifications, timeout, and v1 wire decoding\n");
    CHECK(strcmp(pb_game_state_name(PB_GAME_NOT_LOADED), "not loaded") == 0);
    CHECK(strcmp(pb_game_state_name(PB_GAME_LOADED_UNKNOWN), "loaded, state unknown") == 0);
    CHECK(strcmp(pb_game_state_name(PB_GAME_ACTIVE_RUNNING), "active") == 0);
    CHECK(strcmp(pb_game_state_name(PB_GAME_SUSPENDED_OR_HOME), "suspended or Home") == 0);
    CHECK(strcmp(pb_game_state_name(99), "unknown") == 0);
    CHECK(!pb_game_state_query(NULL));
    {
        pb_game_state state;
        memset(&state, 0xA5, sizeof state);
        CHECK(!pb_game_state_query(&state));
        CHECK((unsigned char)state.titleid[0] == 0xA5);
    }
    {
        server_fixture f;
        pthread_t thread;
        pb_game_state state;
        memset(&f, 0, sizeof f);
        f.response.version = PB_GAME_STATE_VERSION;
        f.response.classification = PB_GAME_ACTIVE_RUNNING;
        f.response.confidence = 3;
        f.response.pid = 123;
        f.response.proc_state = 4;
        f.response.runtime_us = 0x0102030405060708ULL;
        f.response.pctcpu = 17;
        f.response.game_appid = 0x2018;
        f.response.controller_focus = 0x2018;
        f.response.fw_version = 0x0A60;
        memcpy(f.response.titleid, "PPSA12345", 9);
        memcpy(f.response.contentid, "UP0001-PPSA12345_00-TEST000000000000", 37);
        memcpy(f.response.comm, "eboot.bin", 9);
        memcpy(f.response.focus_to, "Game AppScene", 13);
        memcpy(f.response.lifecycle, "resume", 6);
        memcpy(f.response.reason, "game owns controller focus", 27);
        CHECK(start_server(&f, &thread));
        if (f.fd >= 0) {
            memset(&state, 0, sizeof state);
            CHECK(pb_game_state_query(&state));
            pthread_join(thread, NULL);
            CHECK(f.request_ok);
            CHECK(state.version == 1 && state.classification == PB_GAME_ACTIVE_RUNNING);
            CHECK(state.confidence == 3 && state.pid == 123 && state.proc_state == 4);
            CHECK(state.runtime_us == 0x0102030405060708ULL);
            CHECK(state.pctcpu == 17 && state.game_appid == 0x2018 && state.controller_focus == 0x2018);
            CHECK(strcmp(state.titleid, "PPSA12345") == 0);
            CHECK(strcmp(state.comm, "eboot.bin") == 0 && strcmp(state.lifecycle, "resume") == 0);
        }
    }
    {
        server_fixture f;
        pthread_t thread;
        pb_game_state state;
        memset(&f, 0, sizeof f);
        f.status = htonl(5);
        CHECK(start_server(&f, &thread));
        if (f.fd >= 0) {
            memset(&state, 0, sizeof state);
            CHECK(!pb_game_state_query(&state));
            pthread_join(thread, NULL);
        }
    }
    {
        server_fixture f;
        pthread_t thread;
        pb_game_state state;
        memset(&f, 0, sizeof f);
        f.response.version = PB_GAME_STATE_VERSION + 1;
        f.response.classification = PB_GAME_ACTIVE_RUNNING;
        CHECK(start_server(&f, &thread));
        if (f.fd >= 0) {
            memset(&state, 0, sizeof state);
            CHECK(!pb_game_state_query(&state));
            pthread_join(thread, NULL);
        }
    }
    if (fail) return 1;
    puts("game-state client: PASS");
    return 0;
}

#!/usr/bin/env python3
"""Embed a binary file as a C byte array: embed.py INPUT OUTPUT SYMBOL."""
import pathlib
import sys

if len(sys.argv) != 4:
    raise SystemExit("usage: embed.py INPUT OUTPUT SYMBOL")
src, dst, symbol = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]), sys.argv[3]
data = src.read_bytes()
with dst.open("w", newline="\n") as f:
    f.write("/* Generated from %s by tools/embed.py. */\n" % src.as_posix())
    f.write("const unsigned char %s[] = {\n" % symbol)
    for start in range(0, len(data), 16):
        f.write("    " + ", ".join("0x%02x" % b for b in data[start:start+16]) + ",\n")
    f.write("};\nconst unsigned int %s_len = sizeof %s;\n" % (symbol, symbol))

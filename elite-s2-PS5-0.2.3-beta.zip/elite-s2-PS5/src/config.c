#include "config.h"
#include "log.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static const struct { const char *key; const char *shown; uint32_t bit; } k_buttons[] = {
    { "l1", "L1", PAD_L1 }, { "r1", "R1", PAD_R1 }, { "l2", "L2", PAD_L2 }, { "r2", "R2", PAD_R2 },
    { "l3", "L3", PAD_L3 }, { "r3", "R3", PAD_R3 },
    { "cross", "Cross", PAD_CROSS }, { "circle", "Circle", PAD_CIRCLE },
    { "square", "Square", PAD_SQUARE }, { "triangle", "Triangle", PAD_TRIANGLE },
    { "up", "Up", PAD_UP }, { "down", "Down", PAD_DOWN },
    { "left", "Left", PAD_LEFT }, { "right", "Right", PAD_RIGHT },
    { "options", "OPTIONS", PAD_OPTIONS }, { "create", "CREATE", PAD_CREATE },
    { "touchpad", "Touchpad", PAD_TOUCHPAD },
};
#define N_BUTTONS (sizeof k_buttons / sizeof k_buttons[0])

void config_defaults(padbridge_config *c)
{
    c->menu_combo = PAD_OPTIONS | PAD_L2 | PAD_R2;
    c->menu_hold_ms = 1500;
    c->paddle_map[0] = PAD_L3;       /* upper right */
    c->paddle_map[1] = PAD_R3;       /* lower right */
    c->paddle_map[2] = PAD_CREATE;   /* upper left */
    c->paddle_map[3] = PAD_TOUCHPAD; /* lower left */
}

int config_parse_combo(const char *text, uint32_t *mask)
{
    char buf[96], *tok, *save = NULL;
    uint32_t m = 0;
    int n = 0;

    if (!text || strlen(text) >= sizeof buf) return 0;
    strcpy(buf, text);
    for (tok = strtok_r(buf, "+ ", &save); tok; tok = strtok_r(NULL, "+ ", &save)) {
        size_t i;
        char *p;
        for (p = tok; *p; p++) *p = (char)tolower((unsigned char)*p);
        for (i = 0; i < N_BUTTONS; i++)
            if (strcmp(tok, k_buttons[i].key) == 0) break;
        if (i == N_BUTTONS) return 0;               /* unknown name */
        if (!(m & k_buttons[i].bit)) n++;
        m |= k_buttons[i].bit;
    }
    if (n < 2) return 0;
    *mask = m;
    return 1;
}

void config_combo_text(uint32_t mask, char *out, size_t max)
{
    size_t i, n = 0;

    out[0] = '\0';
    for (i = 0; i < N_BUTTONS; i++) {
        int w;
        if (!(mask & k_buttons[i].bit)) continue;
        w = snprintf(out + n, max - n, "%s%s", n ? " + " : "", k_buttons[i].shown);
        if (w < 0 || (size_t)w >= max - n) break;
        n += (size_t)w;
    }
}


int config_parse_button(const char *text, uint32_t *button)
{
    size_t i;
    char name[32];
    size_t n;
    if (!text || !button || (n = strlen(text)) >= sizeof name) return 0;
    memcpy(name, text, n + 1);
    for (i = 0; name[i]; i++) name[i] = (char)tolower((unsigned char)name[i]);
    if (strcmp(name, "none") == 0 || strcmp(name, "disabled") == 0) {
        *button = 0;
        return 1;
    }
    for (i = 0; i < N_BUTTONS; i++) {
        if (strcmp(name, k_buttons[i].key) == 0) {
            *button = k_buttons[i].bit;
            return 1;
        }
    }
    return 0;
}

const char *config_button_name(uint32_t button)
{
    size_t i;
    if (!button) return "none";
    for (i = 0; i < N_BUTTONS; i++)
        if (k_buttons[i].bit == button) return k_buttons[i].key;
    return "none";
}

int config_save(const padbridge_config *c, const char *path)
{
    char tmp[512];
    FILE *f;
    int ok;
    if (!c || !path || snprintf(tmp, sizeof tmp, "%s.tmp", path) >= (int)sizeof tmp) return 0;
    f = fopen(tmp, "w");
    if (!f) return 0;
    ok = fprintf(f,
        "# PadBridge settings\nmenu_combo = ") > 0;
    {
        char combo[96];
        config_combo_text(c->menu_combo, combo, sizeof combo);
        ok = ok && fprintf(f, "%s\nmenu_hold_ms = %d\n", combo, c->menu_hold_ms) > 0;
    }
    ok = ok && fprintf(f,
        "elite_paddle_ur = %s\nelite_paddle_lr = %s\n"
        "elite_paddle_ul = %s\nelite_paddle_ll = %s\n",
        config_button_name(c->paddle_map[0]), config_button_name(c->paddle_map[1]),
        config_button_name(c->paddle_map[2]), config_button_name(c->paddle_map[3])) > 0;
    if (fclose(f) != 0) ok = 0;
    if (!ok || rename(tmp, path) != 0) { unlink(tmp); return 0; }
    return 1;
}

static char *trim(char *s)
{
    char *e;

    while (*s == ' ' || *s == '\t') s++;
    e = s + strlen(s);
    while (e > s && (e[-1] == ' ' || e[-1] == '\t' || e[-1] == '\n' || e[-1] == '\r')) *--e = '\0';
    return s;
}

int config_load(padbridge_config *c, const char *path)
{
    char line[160];
    FILE *f = fopen(path, "r");
    int bad = 0, no = 0;

    if (!f) return 0;
    while (fgets(line, sizeof line, f)) {
        char *eq, *key, *val;
        no++;
        key = trim(line);
        if (!*key || *key == '#') continue;
        eq = strchr(key, '=');
        if (!eq) {
            log_line("config %s:%d: not understood", path, no);
            bad++;
            continue;
        }
        *eq = '\0';
        val = trim(eq + 1);
        key = trim(key);
        if (strcmp(key, "menu_combo") == 0) {
            uint32_t m;
            if (config_parse_combo(val, &m)) {
                c->menu_combo = m;
                continue;
            }
        } else if (strcmp(key, "menu_hold_ms") == 0) {
            int v = atoi(val);
            if (v >= 500 && v <= 5000) {
                c->menu_hold_ms = v;
                continue;
            }
        } else if (strncmp(key, "elite_paddle_", 13) == 0) {
            static const char *names[4] = { "elite_paddle_ur", "elite_paddle_lr", "elite_paddle_ul", "elite_paddle_ll" };
            uint32_t button;
            int i;
            for (i = 0; i < 4; i++) if (strcmp(key, names[i]) == 0) break;
            if (i < 4 && config_parse_button(val, &button)) {
                c->paddle_map[i] = button;
                continue;
            }
        }
        log_line("config %s:%d: '%s' is not valid, default kept", path, no, key);
        bad++;
    }
    fclose(f);
    return bad;
}

/* The host's internals, shared by the Classic (host.c) and LE (le.c) halves
 * of the stack. Not for use outside them. */
#ifndef PH_HOST_INT_H
#define PH_HOST_INT_H

#include "host.h"
#include "profiles.h"

#include <stdint.h>

/* ---- protocol constants ------------------------------------------------- */

/* HCI opcodes: OGF << 10 | OCF. */
#define OP_INQUIRY              0x0401
#define OP_INQUIRY_CANCEL       0x0402
#define OP_CREATE_CONNECTION    0x0405
#define OP_DISCONNECT           0x0406
#define OP_ACCEPT_CONNECTION    0x0409
#define OP_REJECT_CONNECTION    0x040A
#define OP_LINK_KEY_REPLY       0x040B
#define OP_LINK_KEY_NEG_REPLY   0x040C
#define OP_PIN_CODE_REPLY       0x040D
#define OP_AUTH_REQUESTED       0x0411
#define OP_SET_ENCRYPTION       0x0413
#define OP_IO_CAP_REPLY         0x042B
#define OP_USER_CONFIRM_REPLY   0x042C
#define OP_SET_EVENT_MASK       0x0C01
#define OP_WRITE_LOCAL_NAME     0x0C13
#define OP_WRITE_SCAN_ENABLE    0x0C1A
#define OP_WRITE_CLASS_OF_DEV   0x0C24
#define OP_WRITE_INQUIRY_MODE   0x0C45
#define OP_WRITE_SSP_MODE       0x0C56
#define OP_READ_BUFFER_SIZE     0x1005
#define OP_READ_BD_ADDR         0x1009
#define OP_READ_SCAN_ENABLE     0x0C19
#define OP_READ_SSP_MODE        0x0C55

#define CID_SIGNALING   0x0001
#define PSM_SDP         0x0001
#define PSM_HID_CTRL    0x0011
#define PSM_HID_INTR    0x0013

/* Our ends of a link's channels (CIDs are per link). */
#define CID_SDP         0x0040
#define CID_CTRL        0x0041
#define CID_INTR        0x0042

/* L2CAP signaling codes. */
#define SIG_REJECT      0x01
#define SIG_CONN_REQ    0x02
#define SIG_CONN_RSP    0x03
#define SIG_CFG_REQ     0x04
#define SIG_CFG_RSP     0x05
#define SIG_DISC_REQ    0x06
#define SIG_DISC_RSP    0x07
#define SIG_ECHO_REQ    0x08
#define SIG_ECHO_RSP    0x09
#define SIG_INFO_REQ    0x0A
#define SIG_INFO_RSP    0x0B

/* HID transaction headers. */
#define HID_DATA_INPUT  0xA1
#define HID_DATA_OUTPUT 0xA2
#define HID_CONTROL_UNPLUG 0x15

/* ---- timing (ms) -------------------------------------------------------- */

#define T_SELF_AUTH      800    /* a reconnecting pad may authenticate itself */
#define T_SELF_ENCRYPT  1500    /* ... and start encryption itself */
#define T_SELF_CHANNELS 1200    /* ... and open its own HID channels */
#define T_INTR_AFTER     500    /* interrupt channel after control */
#define T_CONN_TIMEOUT 20000    /* paging a pad */
#define T_SETUP_TIMEOUT 30000   /* connection to ready */
#define T_CHAN_CONNECT  2500
#define T_CFG_RESEND    1200
#define CFG_TRIES          6
#define T_CFG_TIMEOUT   4000    /* the pad's own request may have been lost */
#define T_SDP_RESEND    2000
#define SDP_TRIES          3
#define T_INIT_STEP       60    /* between wake-up reports */
#define T_INIT_RETRY     800    /* before repeating an unanswered sequence */
#define INIT_ROUNDS        5

#define SDP_Q_IDS          1    /* Device ID: vendor and product */
#define SDP_Q_DESC         2    /* HID report descriptor, for the generic profile */
#define T_PROBE_IDLE   20000    /* nothing heard for this long: probe */
#define T_PROBE_WAIT    2000    /* between probes */
#define PROBE_TRIES        3

/* ACL flow control on the shared controller: a few Number Of Completed
 * Packets reports go to the system's driver, so a packet without a report
 * after INFLIGHT_MS is taken as sent. */
#define INFLIGHT_MAX      64
#define INFLIGHT_MS       60

#define DB_MAX            16
#define DB_REC            64    /* one record in the store file */
#define DB_MAGIC     "PADBRG02"

/* ---- state -------------------------------------------------------------- */

typedef enum { CH_CLOSED, CH_CONNECTING, CH_CONFIG, CH_OPEN } chan_state;

typedef struct {
    unsigned psm, scid, dcid;
    chan_state st;
    int cfg_ours_ok;        /* the pad accepted our configuration */
    int cfg_theirs_ok;      /* we accepted the pad's */
    int cfg_tries;
    long t_state, t_cfg;
} chan;

/* A paired pad. Classic pads keep a link key; LE pads a long-term key
 * (with its EDIV and Rand under legacy pairing) and possibly an identity
 * resolving key, to recognise them behind private addresses. */
typedef struct {
    unsigned char addr[6], key[16], type;
    uint16_t vid, pid;
    uint8_t le, addr_type;
    uint16_t ediv;
    uint8_t rand[8], irk[16], has_irk;
} db_rec;

typedef struct {
    int credits, max;
    long inflight[INFLIGHT_MAX];
    int head, count;
} acl_pool;

#define LE_MAX_CHARS 24

typedef struct {
    uint16_t decl, value, end, uuid;
    uint8_t props;
    uint8_t rid, rtype;             /* from its Report Reference */
    uint16_t ref, cccd;             /* descriptor handles, 0 if none */
} gatt_char;

/* An LE pad's pairing (SMP) and GATT discovery. Crypto values are kept
 * most significant byte first, as the specification writes them. */
typedef struct {
    uint8_t addr_type;

    int smp;                        /* SMP_* */
    int sc;                         /* LE Secure Connections */
    uint8_t preq[7], pres[7];       /* the pairing commands, as sent */
    uint8_t na[16], nb[16], cb[16];
    uint8_t pkb[64];                /* the pad's public key, as sent */
    uint8_t dhkey[32];              /* least significant byte first */
    int have_pkb, have_cb, have_nb, have_dhkey, dhkey_asked;
    uint8_t ltk[16];                /* the key the link is encrypted with */
    uint8_t keys_expected, keys_got;
    uint8_t dist_ltk[16], dist_rand[8], dist_irk[16], id_addr[6], id_type;
    uint16_t dist_ediv;
    int enc_sent, bonded;
    long t_smp, t_enc;

    int gatt;                       /* G_* */
    uint16_t mtu;
    uint8_t req[32];
    int req_len, req_tries;
    long t_req;
    uint16_t svc_start, svc_end, cursor;
    gatt_char ch[LE_MAX_CHARS];
    int nch, idx;
    uint16_t map_handle;
    uint8_t map[1024];
    int map_len;

    /* Connecting (LC_*): scan off, create, and on a refusal cancel and
     * try again. Statuses are -1 until their reply is seen. */
    int cstate, ctries, cancel_needed, cancel_done, saw02;
    int st_scan, st_create, st_cancel;
    long t_cstate, t_retry;
    uint8_t addr02[6];              /* whose connection the cancel ended */
} le_link;

typedef struct {
    int used;
    unsigned char addr[6];
    int connected;          /* the ACL link is up */
    unsigned handle;
    int pairing;            /* we found it in pairing mode */
    long t_create, t_conn;

    int auth_sent, auth_ok, enc_sent, enc_on;
    long t_auth_ok, t_secure;

    int ids_known;
    int descriptor_requested;
    uint16_t vid, pid;
    const pad_profile *prof;

    int sdp_query;                  /* SDP_Q_* being asked, 0: none */
    int sdp_sent, sdp_tries;
    unsigned sdp_tid;
    long t_sdp;
    unsigned char sdp_cont[16];     /* continuation of a long answer */
    int sdp_cont_len;
    unsigned char sdp_buf[1024];    /* attribute lists gathered so far */
    int sdp_len;

    chan sdp, ctrl, intr;
    int ready, disconnecting;

    unsigned char rx[1024];
    int rx_len, rx_need;

    pad_state st;
    pad_output out;
    long t_out;
    long rumble_until;              /* a test pulse to stop then, 0 if none */

    /* The profile's own memory, and its wake-up sequence. */
    union { unsigned char bytes[PROFILE_CTX_MAX]; uint64_t align; } pctx;
    int init_step, init_rounds, init_done, full;
    long t_init;

    int le;                         /* a Bluetooth LE link */
    le_link le_s;
} link_t;

struct host {
    hci_t hci;
    host_events ev;
    char db_path[256];
    char map_dir[256];
    db_rec db[DB_MAX];
    int ndb;

    link_t links[HOST_MAX_PADS];
    unsigned char sig_id;

    unsigned cc_op;
    unsigned char cc[HCI_PKT_MAX];
    int cc_len;

    unsigned acl_mtu;
    acl_pool br;                    /* the controller's ACL buffers */

    /* Bluetooth LE (le.c) */
    int le_ok;                      /* the controller does LE */
    int le_separate;                /* LE has its own buffers */
    unsigned le_mtu;
    acl_pool lep;
    unsigned char bdaddr[6];        /* our address */
    unsigned char le_pk[64];        /* our P-256 public key, as sent */
    int le_pk_ok;
    int le_scanning, le_scan_want;
    long t_scan;
    int le_scan_out;                /* scan enable commands not answered yet */
    int le_scan_last;               /* the last value sent */
    struct { unsigned char addr[6]; long until; } le_hold[4];  /* no attempt before */
    int le_hold_next;
    long le_diag_t;                 /* diagnostics rate limit */
    int le_diag_n, le_diag_skipped;
    link_t *dhkey_owner;            /* the link a DHKey is being made for */

    long pair_until;
    long purge_at;                  /* when stale links were last cleared */
    int inquiring;
    int dead;               /* the transport is gone */
    int diag_done;          /* the transport's self-report was logged */
    int scan_orig, scan_set; /* page scan as found, and as we set it (-1: untouched) */
    long last_rx, probe_at; /* liveness: anything heard, last probe */
    int probes;
};


/* ---- shared between host.c and le.c ---- */

const char *addr_str(const unsigned char *a);
int  send_cmd(host_t *h, unsigned op, const void *p, int len);
int  hci_sync(host_t *h, unsigned op, const void *p, int plen);
int  slot_of(host_t *h, const link_t *l);
link_t *link_by_addr(host_t *h, const unsigned char *a);
link_t *link_new(host_t *h, const unsigned char *addr);
void link_free(host_t *h, link_t *l);
void link_disconnect(host_t *h, link_t *l, const char *why);
void link_ready(host_t *h, link_t *l);
void link_input(host_t *h, link_t *l, const unsigned char *rep, int len);
int  l2_send(host_t *h, link_t *l, unsigned cid, const unsigned char *d, int len);
void init_tick(host_t *h, link_t *l, long now);

db_rec *db_find(host_t *h, const unsigned char *addr);
db_rec *db_put(host_t *h, const unsigned char *addr);
void db_save(host_t *h);
void db_forget(host_t *h, const unsigned char *addr);

/* le.c */
void le_setup(host_t *h);
void le_on_meta(host_t *h, const unsigned char *ev, int len);
void le_on_frame(host_t *h, link_t *l, unsigned cid, const unsigned char *d, int len);
void le_on_encryption(host_t *h, link_t *l, int status, int on);
void le_step(host_t *h, link_t *l, long now);
void le_poll(host_t *h, long now);
void le_on_cmd_complete(host_t *h, unsigned op, int status);
void le_on_create_status(host_t *h, int status);
void le_abandon(host_t *h, link_t *l);
void le_shutdown(host_t *h);
int  le_send_report(host_t *h, link_t *l, const unsigned char *rep, int len);

#endif
